package com.travelmaker.yeoga.controller;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name ="CALLENDER")

public class CALLENDERController {

    @Id
    private String CALLENDERID;

    @Column
    private String SCHEDULE;

    @Column
    private String COURSEID;

    @Column
    private String UUID;

    @Column
    private String PATHID;

}
