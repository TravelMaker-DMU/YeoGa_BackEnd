package com.travelmaker.yeoga.controller;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table

public class PATHcontroller {
    @Id
    private String PATHID;

    @Id
    private String TRANSPORTATION;

    @Id
    private String DEPATURE;

    @Id
    private String ARRIVAL;
}
