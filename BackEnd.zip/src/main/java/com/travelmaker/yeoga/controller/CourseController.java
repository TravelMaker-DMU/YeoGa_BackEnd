package com.travelmaker.yeoga.controller;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
@Data
@Table

public class CourseController {

    @Id
    private String COURSEID;

    @Column
    private String COURSETITLE;

    @Column
    private int RECOMMENDATION;

    @Column
    private Date CREATIONDATE;

    @Column
    private String THEMEID;

    @Column
    private String LODGINGID;

    @Column
    private String RESTAURANTID;

    @Column
    private String CITYID;


}
